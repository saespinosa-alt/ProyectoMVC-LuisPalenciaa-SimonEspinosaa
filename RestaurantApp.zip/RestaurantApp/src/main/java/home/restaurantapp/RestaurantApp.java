package home.restaurantapp;



/**
 * Aplicación principal JavaFX del restaurante.
 */

import controllers.RestaurantController;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import views.RestaurantView;


public class RestaurantApp extends Application {

    @Override
    public void start(Stage stage) {
        RestaurantView restaurantView = new RestaurantView();
        RestaurantController controller = new RestaurantController(restaurantView);
        controller.setAppStage(stage);

        Spinner<Integer> tableSpinner = new Spinner<>();
        tableSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 40, 12));

        Button generateBtn = new Button("Generar mesas");
        generateBtn.getStyleClass().add("primary-btn");
        generateBtn.setOnAction(e -> controller.initTables(tableSpinner.getValue()));

        Button menuBtn = new Button("Menú");
        menuBtn.getStyleClass().add("primary-btn");
        menuBtn.setOnAction(e -> controller.openMenuEditor());

        HBox topBar = new HBox(10, new Label("Mesas:"), tableSpinner, generateBtn, menuBtn);
        topBar.setPadding(new Insets(12));
        topBar.getStyleClass().add("top-bar");

        BorderPane root = new BorderPane();
        root.setTop(topBar);
        root.setCenter(restaurantView);

        Scene scene = new Scene(root, 1300, 1000);
        scene.getStylesheets().add("styles/michelin.css");
        stage.setMaximized(true);

        stage.setTitle("Restaurante - Gestión de Mesas y Pedidos");
        stage.setScene(scene);
        stage.show();

        controller.initTables(tableSpinner.getValue());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
